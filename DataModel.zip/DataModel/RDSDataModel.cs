﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataModel
{
    class RDSDataModel
    {
        private string name;
        private int rdscounterpartyid;


        public string rds_name
        {
            get { return name; }
            set { name = value; }
        }

        public int rds_rdscounterpartyid
        {
            get { return rdscounterpartyid; }
            set { rdscounterpartyid = value; }
        }
    }
}
