﻿using System;

namespace DataModel
{
    class Program
    {
        static void Main(string[] args)
        {
            TDSDataModel t1 = new TDSDataModel();
            t1.tds_id = "12";
            t1.tds_date = "22-06-2021";
            t1.tds_ctvalue = 80;
            t1.tds_counterpartyid =100;

            RDSDataModel r1 = new RDSDataModel();
            r1.rds_name = "abc";
            r1.rds_rdscounterpartyid = 100;

            Console.WriteLine(t1.tds_id);
            Console.WriteLine(t1.tds_date);
            Console.WriteLine(t1.tds_ctvalue);
            Console.WriteLine(t1.tds_counterpartyid);
            Console.WriteLine(r1.rds_name);
            Console.WriteLine(r1.rds_rdscounterpartyid);
        }
    }
}
