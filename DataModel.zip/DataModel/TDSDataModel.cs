﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataModel
{
    class TDSDataModel
    {
        private string tradeid;
        private string date;
        private int ctvalue;
        private int counterpartyid;

        public string tds_id
        {
            get { return tradeid; }
            set { tradeid = value; }
        }
        public string tds_date
        {
            get { return date; }
            set { date = value; }
        }

        public int tds_ctvalue
        {
            get { return ctvalue; }
            set { ctvalue = value; }
        }

        public int tds_counterpartyid
        {
            get { return counterpartyid; }
            set { counterpartyid = value; }
        }
    }
}
